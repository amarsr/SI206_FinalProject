import json
from urllib.request import urlopen
import sqlite3
import requests
from bs4 import BeautifulSoup
import pdb
import re
import os
import googleapiclient.discovery
import billboard
import paralleldots
import time
import GetLyrics_Sentiment_Keys

genius_id =  GetLyrics_Sentiment_Keys.genius_id
genius_pw = GetLyrics_Sentiment_Keys.genius_pw
yt_pw = GetLyrics_Sentiment_Keys.yt_pw
client_token = GetLyrics_Sentiment_Keys.client_token

# Get song info given song title and artist name
# Pulled example from https://github.com/willamesoares/lyrics-crawler

def get_song_lyrics(song, artist):
    try:
        #Clean Artists
        artist = artist.lower()
        escape = ["featuring", "(featuring", "&", "x"]
        temp = []
        artist_list = artist.split(' ')
        for word in artist_list:
            if word in escape:
                break
            temp.append(word)
        artist = " ".join(temp)

        #clean Songs
        song = song.lower()
        song_temp = []
        song = re.sub('\/.+','',song)
        song_list = song.split(' ')
        for word in song_list:
            if "(from" in word:
                break
            song_temp.append(word)
        song = " ".join(song_temp)


        base_url = 'https://api.genius.com'
        headers = {'Authorization': 'Bearer ' + client_token}
        search_url = base_url + "/search"
        search_results = {'q': song + " " + artist}
        response = requests.get(search_url, params = search_results, headers = headers)
        all_hits = json.loads(response.text)
        
        song_url = all_hits['response']['hits'][0]['result']['url']

        for hit in all_hits['response']['hits']:
            if hit['result']['primary_artist']['name'].lower() == artist:
                song_info = hit
                break
        
        page = requests.get(song_url)
        html = BeautifulSoup(page.text, 'html.parser')
        lyrics = html.find('div', class_ = 'lyrics').get_text()

        # By removing left and right parenthesis, we include ad-libs as words in the song
        # Also remove the [Chorus, Hook, Verse] brackets that Genius adds
        lyrics = re.sub('\?|\.|\,|\!|\(|\)|\[.+?\]', '', lyrics)
        lyrics = re.sub('\n', ' ', lyrics)

        return str(lyrics)
    except:
        return 'NA'



def analyze_text(song_text):
    
    my_key = GetLyrics_Sentiment_Keys.my_key

    paralleldots.set_api_key(my_key)
    return paralleldots.sentiment(song_text)


if __name__ == "__main__":
    
    conn = sqlite3.connect('SIfinal.sqlite')
    cur = conn.cursor()

    cur.execute('CREATE TABLE if Not Exists Lyrics_Sentiment (ID INTEGER, Lyrics TEXT, Negative INTEGER, Neutral INTEGER, Positive INTEGER)')
    sql = 'INSERT INTO Lyrics_Sentiment (ID, Lyrics, Negative, Neutral, Positive) Values(?,?,?,?,?)'

#####Manually enter a start and end for ID values up to 7 digits apart to gather lyrics and sentiment scores for 5 songs###########
         ########## the start and end digits will not gether info for coresponding IDs - only between digits##########

    startCount = 0
    endCount = startCount + 7

    cur.execute('SELECT ID, Artist, Song FROM Top_Songs WHERE ID>{} and ID<{}'.format(startCount, endCount))
    rows = cur.fetchall()

    for row in rows:
        ID = row[0]
        lyrics = get_song_lyrics(str(row[2]),str(row[1]))
        neg_sent = analyze_text(lyrics)['sentiment']['negative']
        neutral_sent = analyze_text(lyrics)['sentiment']['neutral']
        positive_sent = analyze_text(lyrics)['sentiment']['positive']

        val = (ID, lyrics, neg_sent, neutral_sent, positive_sent)
        cur.execute(sql, val)
        conn.commit()

